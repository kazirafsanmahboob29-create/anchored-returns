# Empirical protocol v0.1.3: October 1, 2026

I adopted this amendment on October 1 to govern sample selection, source-backed numeric entry and passage coding alongside the preserved v0.1.2 codebook. It supersedes the earlier author-only coding restriction. Labels from the current workflow are **assistant-coded**; they are not independent human ratings or a classifier-validation set. I preserve the original documents and disclose coder identity in the ledger.

This is a prospective workflow amendment before pilot passage coding, not a preregistration: the motivating case, candidate documents and 26 previously verified facts were already known. No causal finding is presupposed. The 15-order pilot is descriptive.

## Sampling

- Freeze the available written-decision frame as of October 1, 2026. Include original final electric/gas decisions dated January 1, 2019 through the freeze date; exclude pending matters, meeting votes without written reasons, mechanical updates and rehearings as separate observations.
- Retain 15 orders, all six states represented, maximum four per state, at least five 2019–2021, at least five 2023 onward, at least two Vermont setting/formula orders, and NH DE 24-070 included by design.
- Search official commission rate-case indexes and docket records. Log every considered decision, its procedural classification and the evidence for inclusion/exclusion. A failed download is an unresolved record, not an eligibility exclusion.
- Use litigated decisions; partial settlements are eligible when the ROE issue is decided on the record rather than stipulated. A shared recommendation does not itself establish a formal settlement. Apply the existing settled-substitute rule only after the state search supports it, and identify substitutes explicitly. If these rules cannot produce 15, report infeasibility rather than quietly relaxing them.
- Among eligible decisions, prefer the latest written dates subject to all quotas. Operationally, sort descending by date, then ascending state, docket and utility; choose the lexicographically earliest feasible 15-element subsequence. Quota-driven older selections and any unresolved more-recent candidates must be visible in the log. Do not rank by award, request gap or observed reasoning.
- A distinct original final written order is an observation. Separate utility decisions in one docket can be separate observations if they separately determine the utility's ROE; retain a common proceeding identifier and disclose shared reasoning. A single joint decision is one observation, not duplicated by service or utility.
- Assign P01–P15 only after eligibility and the selection log are complete. Use chronological date/state/docket/utility order for permanent IDs. Before then, use source-specific candidate IDs. Do not present a provisional list as a finalized sample.

Download, source-check and coding dates can follow the frozen written-decision cutoff. Record those actual dates separately and retain dated releases; the cutoff governs decision eligibility, not the date work was performed.

## Coding clarifications

- `OWN` takes precedence for this commission's own prior authorized returns, including its awards for another in-state utility. `PEER` means authorized returns of other commissions. Apply both only when both comparison types occur. A citation to an earlier case solely for a legal/model rule is not an ROE-history comparison.
- Preserve the 11 original codes and the paragraph as printed as the unit. Split mixed party/commission voice, preserve cross-page continuations and footnotes, and retain page/offset provenance. Code all paragraphs in the ROE section plus a distinct award-announcement paragraph elsewhere; do not select only passages that fit the hypothesis.
- Read each full ROE section before assigning labels. Make contextual decisions passage by passage, recording a short rationale; keyword hits alone are not codes. Structural/procedural paragraphs can have all codes zero with primary `n.a.` where the schema permits it. Ambiguity stays in notes.
- The workbook stance belongs to the primary code. Record per-code stances separately in the coding ledger for secondary codes; never copy the primary stance mechanically. `Summarized only` applies to party/ALJ accounts; distinguish the commission's adoption, consideration and rejection.
- Expected earnings remains MKT; distinguish it from authorized-award comparisons. Preserve mixed-method ambiguity for the report's sensitivity bounds.
- CONC requires a whole-analysis judgment. A bare award sentence is not CONC if another analysis passage connects the choice to evidence. Explain the chosen case-level rationale and whether a range is justified separately from its selected point.
- Record coder as Codex assistant, codebook version, actual coding date and any revisions. Recorded timing and paired ratings require actual observations. Reliability remains unmeasured until genuinely separate observations with documented provenance exist.

## Numeric data and dates

- Enter numbers from the original decision with exact quotation/offset, viewer page, URL and file hash; inspect rendered numeric evidence. Keep original awards separate from later modifications. Preserve inequalities and ranges rather than converting them into point recommendations.
- Store ROEs as fractions and performance adjustments as signed basis points. Record zero adjustment only when the decision supports it. Initial and final requests require distinct chronology evidence; do not infer an initial request from a witness range.
- Use a stated prior authorized ROE with the corresponding prior decision date; verify the linked decision where available. A previously effective formula value without an identifiable decision date cannot form a matched prior/current interval.
- Join DGS10 using the written order date, or the latest earlier published nonmissing observation. Never backfill from a future day. Record actual observation date, source vintage and calendar-day gap; gaps longer than seven days require investigation. Convert percent to fraction exactly.
- National benchmark: same service, excluding riders, most recent complete half-year before the order date. Keep the half-year and report vintage explicit. Annual averages, cited averages of unclear scope and unavailable proprietary values cannot substitute. Missing entries carry a reason.
- Preserve source-absent, not applicable and unresolved as distinct statuses in the research ledger even where the workbook represents all three as blank. Coverage counts are not source-quality certification.

## Storage and checks

Keep acquired PDFs immutable, with download metadata and hashes. Preserve all earlier module fixtures and reports. Build the empirical workbook as a separate versioned file. If passage capacity must expand, version its schema and all affected formula/validation ranges together, retaining backward compatibility for earlier audited workbooks. Run relevant validation and audit before committing. Report sample completeness, numeric coverage, coding coverage and reliability separately.
