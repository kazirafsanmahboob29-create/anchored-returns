# Reproduction

Install Python 3.11+ and the dependencies with `python -m pip install -e .`. Run `python -m src.factor_study`, then `Rscript analysis/factors.R reports/factor-study`. Inputs include the original EEI workbook, the national normalized records, all hashed national inputs, and four attributed economic histories. The R script checks coefficients and clustered standard errors against Python before drawing the figures. Native Stata syntax is provided but has not been executed. No original-order PDFs or API keys are required.
