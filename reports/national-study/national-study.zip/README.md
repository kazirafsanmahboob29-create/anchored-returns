# Reproducing the national study

This bundle includes the preserved EEI workbook and Treasury retrieval used in the study. The source files retain their publishers' rights.

Install Python 3.11 or later and the declared dependencies with `python -m pip install -e .`, then run `python -m src.national_study`. Outputs are written to reports/national-study. Rscript is used when installed. The supplied cases.csv, annual.csv and Stata tables can also be used directly. No original-order PDFs are needed for the national calculation. The broader New England document tools require their separate source archive.
