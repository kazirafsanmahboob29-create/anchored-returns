# Independent coding packet

Kazi Rafsan Mahboob

I am collecting separate ratings for 67 text units from three orders. This packet contains definitions, source-page context and a blank coding workspace. Reference labels and research findings are excluded.

Extract the entire ZIP before opening files. Keep the folder structure intact. Open `data/research/reliability/three-orders-2026-10-02/rater/index.html`. The page includes its data and controls; a local web server is not required. The original codebook and protocol amendment are linked from the page.

Read the definitions and all section context before rating. Do not consult the project site, first-pass labels or another rater. Record your actual identity and blinding statement. Mark every code present or absent for every unit, including units with no codes. Save a draft to resume and export the completed JSON when finished. Return that file to the researcher. Keep independent raters' work separate.

No completed ratings or agreement statistics are included. The three orders are not a representative reliability sample of the final 15-order study.
