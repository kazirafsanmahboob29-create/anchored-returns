# Hosted research workspace

I publish Anchored Returns at [the hosted research workspace](https://anchored-returns-mahboob.rafsanmahboob28.chatgpt.site). Version 1 was deployed on October 6, 2026. The site is separate from Gridline and currently uses private access through ChatGPT sign-in.

The workspace provides the evidence explorer, original PDF pages with fingerprint checks, source links, filtered CSV exports, descriptive findings, source-to-finding connections, R and Python figures, Stata datasets and scripts, research tool downloads, and the separate coding workspace. The hosted services operate without a local server running on my computer.

The FRED DGS10 and Treasury XML connections preserve raw responses and comparison records in hosted storage. Routine page loads check for a retrieval at least one hour old. The source-check button reuses a retrieval completed within the preceding 15 minutes. Failed retrievals retain the previous complete snapshot. Market updates do not modify the fixed empirical release, historical joins or research figures.

The deployment's first verified market retrieval compared 190 same-date observations in 2026; all agreed. FRED's latest observation was October 2, 2026 at 5.28 percent. Treasury's latest observation was October 5, 2026 at 5.31 percent. Different latest dates are reported separately.

The fixed research release remains dated October 4, 2026. Its 15-order allocation is provisional, five comparable half-year benchmarks remain unavailable, and independent ratings have not been collected. Deployment does not resolve these empirical limits.

The release passed 479 research tests and six hosting tests. I checked 136 release-file fingerprints, 152 local dashboard links, desktop and mobile layouts, PDF rendering, filter tools and both research archives. Authorized requests to the published services confirmed source refresh, persistent retrieval storage, original PDF downloads, the coding workspace and the research bundle. The private sign-in gate prevented a separate browser session from visually inspecting the production page; the interface was inspected locally, and its published assets and services were checked directly.

The deployment source is maintained in the adjacent `anchored-returns-site` directory. The Python project exports a checked release through `scripts/build_hosted_release.py`. The deployment retains its Site identity across updates. The detailed verification record is in `reports/deployment_2026-10-06.json`.
