# M1–M8 module reference

Individual module commands and historical practice examples are retained here. For the current workflow, use [USAGE](USAGE.md), `./research status`, and the [evidence explorer](../presentation/index.html). Counts inside older examples describe their original execution stage.


All commands below run from the `anchored-returns` repository folder. This is a local command-line toolkit. Existing PDFs, extracted text, and saved page suggestions can also be opened directly without running anything.

Start with the [project overview](../README.md) for current capabilities and missing work. See the [report index](../reports/README.md) for evidence and historical notes.

## First use without environment activation

The project already contains its own Python environment. This command uses the local environment without shell activation:

```sh
cd '/Users/kazirafsanmahboob/Desktop/Energy Research Builds/anchored-returns'
.conda/envs/anchored-returns/bin/python -m src.locate_roe \
  data/practice_text/PRACTICE-MA-17-05.json --top-n 3
```

It prints JSON with three ranked ranges. For the practice order, the first is `start_page: 670`, `end_page: 742`. The values refer to the PDF viewer's page counter. The printed document labels are 642–714. Inspect both boundary pages because they also contain text from adjacent sections.

Useful output fields:

| Field | Meaning |
|---|---|
| `start_page`, `end_page` | Inclusive viewer-page range to inspect |
| `context_start_page` | Earlier related keyword material omitted when starting at the specific equity heading |
| `score`, `term_counts`, `page_scores` | Why the range ranked highly; the score is not a probability |
| `gap_pages`, `low_text_pages` | Pages that may need extra inspection |
| `confirmed_range`, `human_top_hit` | Unfilled review fields; M3 does not claim a confirmed range or human evaluation |

For any `python` command below, substitute `.conda/envs/anchored-returns/bin/python` to use the environment directly.

## Existing results

The original practice and candidate PDFs in these examples are already registered and extracted. To inspect existing work, open the [practice PDF](../data/practice_orders/MA/17-05_2017-11-30_final_order.pdf), the [saved practice suggestions](../reports/m3_suggestions/PRACTICE-MA-17-05.json), or the [M3 verification report](../reports/m3_and_project_audit.md). Existing registration and extraction do not need to be repeated to use M3.

For a new order, the sequence is **download and verify identity → M1 registration → M2 extraction → M3 suggestions → inspect the PDF**. Practice documents use their separate manifest. Candidate registration never selects the final sample.

## Environment

Run from this repository in zsh:

```sh
cd '/Users/kazirafsanmahboob/Desktop/Energy Research Builds/anchored-returns'
conda activate "$PWD/.conda/envs/anchored-returns"
python --version
python -m pytest -q
```

The Python 3.11 environment is local and ignored by Git. Recreate it with `conda env create --prefix "$PWD/.conda/envs/anchored-returns" --file environment.yml`, then run `python -m pip install -r requirements-lock.txt` inside it. The package snapshot is for the tested macOS setup, not a complete cross-platform Conda lock. The Jupyter kernel is registered within this environment only.

## M1: register a downloaded PDF

Metadata is supplied explicitly after checking the source. For a new document:

```sh
python -m src.manifest '/absolute/path/to/downloaded.pdf' \
  --manifest data/manifest.csv \
  --case-id 'CAND-STATE-DOCKET' \
  --state 'MA' \
  --docket '<verified docket>' \
  --source-url '<official source URL>' \
  --download-date '<actual download date YYYY-MM-DD>'
```

Replace placeholders. Use `data/practice_manifest.csv` for out-of-sample practice. The download date is the actual retrieval date, not the order date. M1 records absolute paths, SHA-256 fingerprints, and viewer page counts without changing the PDF. It refuses duplicate content, duplicate IDs, malformed manifests, and encrypted or repair-dependent PDFs. Registration does not establish eligibility or select a sample case.

The original acquired orders in these examples are already registered. Repeating their registrations must fail with `Duplicate SHA-256`; this check passed for all four. Absolute paths need a deliberate migration if the repository moves. Locked atomic manifest replacement assumes a local macOS/Linux filesystem.

M1 and M2 share the same filename-safe case-ID rule: begin with a letter or digit, then use letters, digits, underscores, hyphens, or dots. Registration now refuses IDs that the downstream extractor cannot use. Existing project IDs already satisfy this rule.

## M2: extract registered PDFs

The following reproduces practice extraction in a fresh output directory:

```sh
python -m src.extract_text \
  --manifest data/practice_manifest.csv \
  --case-id PRACTICE-MA-17-05 \
  --output-dir reports/smoke/practice-rerun \
  --min-text-chars 80
```

Output is a JSON list with exactly `page`, `text`, `n_chars`, and `likely_scanned`. Page numbers are one-based PDF viewer positions, not printed page labels. Native extraction preserves headers, footnotes, and line-break hyphenation for later processing. `n_chars` counts all characters in the output text. `likely_scanned` flags pages with fewer than 80 **non-whitespace native-text** characters. This is an initial screening threshold, not a calibrated scan detector or a text-accuracy guarantee.

M2 checks the PDF hash and page count against the manifest. It refuses existing outputs and protected source/coding folders. Use a new directory for each rerun. The CLI prints a separate JSON audit summary that can be redirected to a report file.

OCR runs only with `--ocr` and an explicit directory containing language data. English data from the official Tesseract repository is saved at `data/external/tessdata/`; its commit, license, and fingerprint are recorded in [the dependency record](../reports/ocr_dependency.json). Example for a fresh output:

```sh
python -m src.extract_text \
  --manifest data/manifest.csv \
  --case-id CAND-RI-4770-4780 \
  --output-dir reports/smoke/ri-ocr-rerun \
  --min-text-chars 80 --ocr \
  --tessdata-dir data/external/tessdata
```

OCR processes only flagged pages. The flag continues to describe the original native text even after recognition. OCR output remains a draft transcription, especially for tables, seals, and handwriting. Existing native extraction stays in `data/text/`; the separate Rhode Island OCR copy is in `data/text_ocr/`.

## M3: suggest the ROE section

```sh
python -m src.locate_roe data/practice_text/PRACTICE-MA-17-05.json
```

The command only reads its input and prints ranked JSON. It does not write to a workbook or select a confirmed range. Defaults are `--top-n 5 --max-gap-pages 2 --min-page-score 4`; all settings and weights are included in the output. The input must satisfy M2's exact schema with consecutive viewer page numbers and matching character counts. Invalid input fails with exit code 2.

The seven search terms are scored with per-page frequency caps. Likely contents pages are excluded, repeated edge headings are discounted, and nearby qualifying pages form candidate ranges. A specific equity heading can trim earlier capital/proxy context, which remains visible as `context_start_page`. The output includes matched-term counts, page scores, gaps, low-text flags, and an input fingerprint. Scores are search heuristics, not probabilities. Search-only normalization never edits the source text.

The practice suggestion starts on the page with the ROE heading and ends on the page containing the conclusion's final text and footnote. Both boundary pages also contain unrelated material. On the RI order, an appendix outranks the commission's own discussion, which appears third. These are suggestions for review, not automatic section or passage classifications. `confirmed_range` and `human_top_hit` remain null. Details and all four local runs are in [the M3 audit report](../reports/m3_and_project_audit.md).

## Recheck saved project work

```sh
python -m pytest -q
python -m scripts.audit_project
```

The read-only audit checks original archive members, 70 locked package versions, downloaded PDF identities, manifest consistency, all saved native text against fresh extraction, OCR preservation, Treasury units/missing values, M3–M8 reproducibility, M4 template preservation, and verified-fact provenance. It prints JSON and exits with an error if a check fails. Optional `--pdfinfo /absolute/path/to/pdfinfo` adds an independent Poppler page-count check, used in the saved audit. It requires the local source downloads and original archive. It does not certify OCR recognition, sample eligibility, original workbook formulas, or paper methods.


## Common situations

| Message or situation | What to do |
|---|---|
| `Duplicate SHA-256` | The identical PDF is already registered. Use its existing row; renaming a file does not create a new order. |
| `Duplicate case_id` | Use the existing record if it is the same order, or a genuinely distinct ID for a different order. |
| `Output already exists` | M2 preserves the previous extraction. Choose a new output directory for a deliberate rerun. |
| PDF fingerprint or page-count mismatch | Investigate the source change and verify the correct document before registering a replacement. |
| No M3 candidates | Inspect the source and extraction quality. Absence of keyword hits is not proof that the order lacks ROE discussion. |
| A high-ranked appendix or party filing | Inspect lower-ranked ranges and the document structure. RI currently demonstrates this limitation. |
| `conda activate` fails | Use the explicit project Python path shown above. |
| Audit reports a missing local source | Restore the exact download or original ZIP from backup; retain its recorded identity and fingerprint. |

## Storage and portability

Research PDFs, rendered QA images, generated text, and OCR model data are stored locally and excluded from Git. Code, provenance, the small Treasury snapshot, and M3 suggestions are tracked. Back up the full project folder together with the original `Energy Research Project.zip`, which the audit expects one directory above the repository.

Manifests and audit records contain absolute paths. Moving the repository or copying it to another computer requires a reviewed path migration, recreating the Python environment, and restoring the source files. The existing environment is usable here; the lock file records this macOS/Python setup and is not a complete cross-platform installer.

The original `project_docs/00_START_HERE.md` is preserved as supplied. Current usage instructions live in this guide and the README. The user has authorized independent source acquisition; no user download is a prerequisite to further software work.

## M4: prepare draft passages

The existing practice workbook is at `data/drafts/PRACTICE-MA-17-05-v1/passages_draft.xlsx`. Open **Passages**, start at row 3, and compare each excerpt with the PDF at its viewer-page references. Row 2 is an illustrative example. Review heading units, paragraph boundaries, quotations, and footnotes before adding research labels. Use the formula bar for any excerpt taller than Excel's maximum row height. This practice copy retains the template Cases placeholders and is not the live pilot workbook.

To reproduce the draft into a **new** directory:

```sh
.conda/envs/anchored-returns/bin/python -m src.segment \
  data/practice_text/PRACTICE-MA-17-05.json \
  data/practice_orders/MA/17-05_2017-11-30_final_order.pdf \
  reports/m4_review_plans/PRACTICE-MA-17-05.json \
  project_docs/Anchored_Returns_Pilot_Coding_Sheet_v0.1.2.xlsx \
  data/drafts/PRACTICE-MA-17-05-review-2
```

M4 writes three files: `passages_draft.xlsx`, `passages.json`, and `audit.json`. The JSON records exact source-line IDs and all line-join changes. `page_para` uses PDF viewer pages and draft part numbers; these are not original printed paragraph numbers. Section, code, stance, coder, and numeric research fields remain blank. Comparison formula columns and summary sheets are hidden in the copy, with original formulas preserved.

For another native, single-column order, prepare a separate reviewed plan using the current JSON as a schema example. Set the actual source fingerprints, inclusive viewer pages, reviewer identity/type, PDF-point layout coordinates, and exact optional start/end anchors. Do not reuse Massachusetts layout values without checking the new PDF. `paragraph_breaks` and `footnote_continuations` identify **page:line** positions in the original M2 text (one-based, including blank lines); the first continuation line is linked to the preceding page's last footnote. `dehyphenate_words` explicitly permits removing a line-end hyphen for the resulting word. Unlisted compounds retain their hyphens and are flagged. Only reviewed boundary-page footnotes should be retained; clipping anchors apply to body text only.

Output must be a fresh directory outside protected source/coding folders. Existing destinations, symlink output paths, changed hashes, populated templates, mismatched schemas, non-native/OCR text, unused line overrides, more than 398 draft units, and overlong Excel cells fail rather than overwrite or truncate. The final audit file is required; an interrupted export may leave an incomplete new directory. Choose a new output name after reviewing any partial bundle.

The current full audit includes M1–M8 and the preserved project summary:

```sh
.conda/envs/anchored-returns/bin/python -m scripts.audit_project
.conda/envs/anchored-returns/bin/python -m pytest -q
```

The audit expects the saved v1 practice bundle at its recorded path. Keep a manually edited review workbook in a separate copy so the reproducibility baseline remains intact. The outline's Python/openpyxl stack is retained for portable workbook generation; no desktop-specific JS runtime is required to run M4.

## M5: find and check numeric candidates

```sh
.conda/envs/anchored-returns/bin/python -m src.number_finder \
  data/text/CAND-NH-24-070.json --start-page 40 --end-page 43
.conda/envs/anchored-returns/bin/python -m src.number_finder \
  data/text/CAND-NH-24-070.json --start-page 1 --end-page 81 --format json
```

Pages are inclusive, one-based PDF viewer positions. The default proximity is 300 original characters from an ROE term; change it with `--window-chars`. The CLI only reads the M2 JSON and prints a table or JSON. Shell redirection can save output to a new file. It never fills a workbook or changes labels. Invalid schemas/ranges return exit code 2. A valid no-match result returns 0 and does not establish that the order lacks ROE figures.

The finder recognizes %, percent, per cent, basic English number words, simple shared-unit ranges, percentage points, and basis points. It retains repeated occurrences and nearby non-ROE numbers. Cross-page proximity is allowed within the requested range; sentences remain page-bounded fragments when necessary. Raw text and zero-based, end-exclusive character offsets are preserved. Actor attribution is a guess; multiple actors produce `ambiguous`. OCR typos are not silently repaired. Text outside the range, missing units, tables with detached units, unsupported words, and poor text extraction can hide values.

Saved full-document candidate tables and JSON are in `data/number_candidates/`; `reports/m5_extraction_audit.json` records configurations and hashes. The RI run uses the separate OCR-enhanced text; its 12 source low-text flags remain visible. These are discovery results, not 1,077 verified ROEs. The current checked facts are separately stored in `data/research/assistant_verified_case_facts.json`, with original percentages, exact fractions, inequalities, conditions, dated source events, and explicit unresolved values. See the [M5 report](../reports/m5_verification.md) and [verification protocol](verification_protocol.md).

Supporting decisions have their own `data/supporting_manifest.csv` and `data/supporting_text/`. They are audited and searchable but do not inflate the candidate/sample count. Back up those generated texts and candidate outputs with the source PDFs; they are Git-ignored. The 26-fact ledger and its provenance are tracked.

## M6: validate a coding workbook

```sh
.conda/envs/anchored-returns/bin/python -m src.validate_sheet \
  data/drafts/PRACTICE-MA-17-05-m6/passages_working.xlsx --scope practice --format json
```

M6 opens the workbook without saving it. The input must follow the supplied v0.1.2 Cases, Passages, Reliability and Lists schemas. It prints all diagnostics, including the sheet, row, field and cell, and records the input/schema hashes. Default text output is available by omitting `--format json`. Redirect stdout to a new report file if desired; the validator itself writes nothing.

- `--mode draft` (default): unfinished metadata/labels are reported separately from errors. Existing invalid entries still fail.
- `--mode complete`: required metadata/coding omissions become errors. Source-absent numeric recommendations may remain blank.
- `--scope pilot` (default): P01–P15, written-order dates in 2019–2026, and sample checks. Untouched placeholders and the exact original EX-01 example are excluded. Modified examples are errors.
- `--scope practice`: separate practice IDs and out-of-frame dates; no pilot quotas or pilot sample-status requirement. All numeric/coding/linkage checks still apply.
- `--fail-on-warnings`: return failure for warnings or unfinished work as well as errors. Use this with complete mode for a strict completion check.

Exit codes: **0** no errors under the selected policy; **1** validation failure; **2** unreadable workbook or invalid invocation. Always read `status`: exit 0 in draft mode can mean `incomplete`. Counts and quota warnings are computed from inputs, not cached Excel values. With fewer than 15 populated case rows the sample is marked in progress; Pre/Post/VT/full-state quota warnings begin at 15, and state-cap warnings apply immediately.

Enter ROEs as 0.095 or Excel's numeric 9.5%, not 9.5 or the text string “9.5%”. Performance adjustments are signed basis points: a 47 bp reduction is **-47**. M6 checks base plus adjustment without overwriting the workbook. A blank adjustment follows the template's zero-adjustment calculation convention, explicitly flagged in the report; it is not verified absence of an adjustment. Source-absent facts stay blank.

For a real upward request revision, put `request_revision_explanation: <reason and source page>` in `sources_notes`. This waives the ordering error but leaves a warning that the explanation needs substantive source checking. Other notes do not waive it. The tool checks code membership and primary-flag consistency, not whether a passage deserves a given code. A case with case-level coding fields or any passage coding started needs a fully coded Commission-analysis passage.

The original M4 workbook is a preserved extraction baseline with no matching practice Cases row. Validate the M6 working copy for ongoing practice work; keep a separate editable copy to preserve its audited baseline. The working copy has one procedure field and 219 label sets unfinished. No human approval is required; labels must accurately disclose who produced them.

Cases rows beyond 17, Passages beyond 400 and Reliability beyond 601 are errors because the supplied formulas would omit those records. Inputs in Cases row 2 are also rejected because Summary excludes that row. Version the workbook/schema together before expanding capacity or categories. M6 verifies Cases formula text on populated rows but does not execute Excel, recompute kappa, or certify all summary calculations.

Before each code/data commit, run M6 on the relevant working workbook and the project audit:

```sh
.conda/envs/anchored-returns/bin/python -m src.validate_sheet \
  data/drafts/PRACTICE-MA-17-05-m6/passages_working.xlsx --scope practice --format json
.conda/envs/anchored-returns/bin/python -m scripts.audit_project
```

The audit also reproduces all nine saved M6 checks, including five intentionally broken synthetic files, and compares the practice working copy against its original. Back up `reports/m6_fixtures/` and the working workbook with all other local source/generated files; both are Git-ignored. The original template, all M4 passages/blank labels, and the 26 M5 historical facts remain preserved. See [M6 verification](../reports/m6_verification.md).

## M7: cross-check coding agreement

```sh
.conda/envs/anchored-returns/bin/python -m src.reliability \
  reports/m7_fixtures/engine-toy.xlsx --format json
```

This **synthetic test** returns `passed`: its eight MKT pairs give kappa 0.50 and match the saved sheet. For a real workbook, replace the path with a separate coding-workbook copy. The current M6 practice file correctly returns `no_data` and exit 1 because no paired ratings have been entered.

On **Reliability**, fill A:D with `passage_id`, `code`, `coding_A`, `coding_B`. Both ratings must be numeric 0 or 1. Each passage must exist in Passages and link to a populated case. Use one row per passage/code pair; the same passage may have rows for several different codes. Preserve the F:O formula summary. Run M6 separately to check the rest of the workbook.

M7 reads inputs and formula text, then independently reads the saved formula results. It calculates an unweighted Cohen kappa for each code using scikit-learn, with counts, observed agreement and expected agreement. It does not pool codes, copy A into B, supply missing ratings or save the workbook. Keep rater identities, coding dates, blinding and independence/repeat-coding information in the research log; the four-column sheet does not establish those facts.

Default mode compares kappa with `Reliability!N2:N12` using the outline's 0.001 tolerance. It also checks support counts exactly, observed/expected agreement within `1e-12`, the project target flag, and the original summary formula patterns. A mismatch raises `ReliabilityMismatchError` in Python. The CLI still prints the full report before returning failure.

If formula results are absent, the report says `incomplete`/`missing_cache`. Recalculate and save a **separate copy** with a spreadsheet engine and rerun. For calculations without a saved-sheet comparison, explicitly request:

```sh
.conda/envs/anchored-returns/bin/python -m src.reliability \
  path/to/workbook-copy.xlsx --compute-only --format json
```

`--compute-only` keeps all schema/rating validation, skips saved-value comparisons, and reports `computed_only` when there are pairs. It does not mean the workbook was checked. Missing ratings are rejected in both modes; they are never silently omitted. Identical constant ratings produce null/undefined kappa, even if observed agreement is 1. No-pair codes are listed with `no_pairs`, not zero or perfect agreement.

Exit codes:

- **0:** arithmetic cross-check passed for all populated codes, or an explicitly requested compute-only run has pairs. Read each code's status; this is not a certificate of independent coding or full code coverage.
- **1:** mismatch, no rating data, unavailable saved values, or undefined kappa in a populated code during comparison.
- **2:** malformed workbook, changed schema/formulas, invalid/partial ratings, duplicate pairs, unknown IDs or invalid invocation.

Omit `--format json` for a readable table. JSON never uses NaN: unavailable kappa is `null`, with a reason in the per-code status. The Python functions are `binary_agreement(a, b)` and `reliability(path, compute_only=False)`; mismatch exceptions expose `.report`.

The [M7 verification report](../reports/m7_verification.md) gives the hand calculation and sources. The project audit reproduces ten saved M7 runs, including expected failures. Three synthetic copies were actually recalculated in bundled Artifact Tool; native Microsoft Excel was not tested. Unit-test caches are separately simulated, never represented as engine execution. `scripts/verify_m7_engine.mjs` records the optional desktop QA procedure; the normal M7 command only needs the project Python environment. Back up local `reports/m7_fixtures/` and `reports/pdf_qa/m7/` evidence, which Git excludes.

## M8: generate the pilot report

```sh
.conda/envs/anchored-returns/bin/python -m src.pilot_report \
  data/drafts/PRACTICE-MA-17-05-m6/passages_working.xlsx \
  reports/practice-report-next --scope practice
```

Open `report.html` inside the new output folder. `memo.pdf` is a two-page print version; `memo.md`, PNG/SVG figures, nine CSV tables, `analysis.json` and `audit.json` accompany it. Separate order plots live in `figures/orders/`. The saved [actual practice report](../reports/m8_practice/report.html) shows current missing data. The [15-order demonstration](../reports/m8_demo/report.html) is explicitly synthetic and is not an empirical finding.

Use `--scope pilot` (default) for a pilot workbook, and `--scope practice` for a separate practice workbook. For software fixtures, add `--synthetic`, which labels the HTML, both PDF pages, the memo and every figure. The included synthetic fixture requires that flag. Inputs are never saved. Existing directories, symlinks and protected source/coding destinations are refused; choose a new report directory per run. In-progress files are removed if that new export fails; `audit.json` is written only when the bundle is complete.

M6 errors, invalid paired ratings and M7 saved-result mismatches stop export. Draft omissions, absent reliability data and missing saved caches remain visible in the report. Numeric source notes are required for entered case numbers. The CLI exits **0** when all report files were generated and **2** for invalid inputs or output failures. Read `workbook_validation_status` and `reliability_comparison_status` separately: output completion is not research completion.

Calculations come from typed inputs, not Excel's cached Cases/Summary formulas. ROEs stay fractional in CSV/JSON and display as percentages in number-line figures. Scatter changes use percentage points and **base** ROE. Both dates, both Treasury observations and both ROEs must exist; missing intervals are listed in `rate_shock_exclusions.csv`. The plotted n is actual coverage, not always 15. A missing performance adjustment leaves final ROE unavailable; enter an explicit 0 only when the source supports no adjustment.

Code shares use fully coded Commission-analysis passages and include all primary stances. They measure presence, not endorsement. Uncoded passages are excluded with coverage counts, rather than treated as zero. Expected-earnings sensitivity changes group membership for reporting only; it does not rewrite code cells. Multiple/Unspecified/n.a. market methods produce conservative bounds when expected-earnings content is unknown. The [M8 verification report](../reports/m8_verification.md) records all denominator and missing-data decisions.

The original workbook has no M3-hit field. Optionally add a worksheet named `M3_Review` to a separate working copy, with these exact headers in A1:F1:

| case_id | top_hit | reviewer | reviewer_type | reviewed_on | evidence |
|---|---|---|---|---|---|
| Existing case ID | Numeric 0 or 1 | Identified reviewer | `assistant` or `human` | Excel date or YYYY-MM-DD | Source/range comparison supporting the hit decision |

One review per case and reviewer type is supported. All fields are required on entered rows. Missing reviews remain unknown and assistant/human rates are never pooled. This optional extension does not change the frozen Cases, Passages or Reliability schemas; no review sheet has been inserted into real research inputs. Do not populate it from a keyword score alone.

The same command regenerates all outputs from the workbook, including any optional review log. `analysis.json` retains source notes and upstream diagnostics, and `audit.json` fingerprints every exported file. Text cells with spreadsheet-formula prefixes are escaped in CSV only; exact source strings remain in JSON. Figure/PDF bytes are reproducible within the locked environment. The full project audit regenerates saved bundles in temporary folders and compares them exactly, without modifying saved inputs/outputs.

The optional developer fixture builder is `python -m scripts.create_m8_demo NEW_FIXTURE.xlsx`; every observation it creates is fabricated. Saved demo Reliability results were recalculated separately in bundled Artifact Tool. The ordinary M8 command only needs the project Python environment. Back up `reports/m8_demo/`, `reports/m8_practice/`, `reports/m8_fixtures/` and QA images with the full folder because they are Git-ignored.
