# Verification protocol: September 30, 2026

I use this protocol for independent public-source acquisition and factual entry. It supersedes earlier requirements for author-supplied materials and human approval while retaining source verification. Historical reports describe the rules in effect when written.

## Source and event rules

1. Prefer a commission's written decision and official docket. Verify the actual downloaded bytes, cover, issuance date, relevant passage, and PDF viewer page. A search snippet, press release, compliance filing, and commission decision are different evidence types.
2. Record original decisions and later modifications as distinct dated events. Preserve the original reasoning for passage analysis; link subsequent decisions. Never silently replace a historical outcome with a later tariff figure. A docket title alone establishes the existence of a filing, not its substantive contents.
3. Record requested ROE, witness recommendations, advocate recommendations, model estimates, authorized ROE, WACC, capital ratios, and performance adjustments separately. Retain inequalities and conditions. A range endpoint is not automatically a point recommendation. A witness estimate does not establish the chronology of a company's requests.
4. Use the written order for the current verified fact ledger. An unresolved fact remains null with a reason. If testimony or another primary filing later supplies a missing fact, label that fallback source and date explicitly; do not present it as text from the order. Secondary commentary cannot silently fill order-only fields.
5. Store original percentages and exact fraction conversions, source URL, PDF/text SHA-256, exact text offsets, viewer page, and assistant verification status. Check the rendered page as well as the extracted text for entered numeric facts. Automated audit validates provenance and arithmetic; it does not independently establish interpretation.
6. An M5 output is always a candidate list. Assistant source checks populate a separate factual ledger. No automatic research coding, sample selection, prior-award substitution, benchmark imputation, or analytical conclusion follows from proximity or actor guesses.
7. I retain the actual coding and verification provenance. A single coder does not supply independent inter-rater reliability, and original human-confirmation fields require actual human observations. Independent reliability remains a measurement limitation.

## Current scope and remaining dependencies

The ledger records historical facts from six candidate orders, plus one linked rehearing event. It is not a finalized sample or a statement of current tariffs. The RI settlement remains conditional; it does not establish that no eligible litigated RI case exists. The Vermont plan approval defers its initial ROE to 23-0561-TF and does not provide that missing number.

The NH docket check identified Order 28,237 (July 21, 2026). Its existence is recorded, but its contents were not acquired. The original and December 2025 ROE facts are supported; their present-day applicability is not certified. Other candidates also require systematic later-order screening before current-status claims.

For national comparisons, require the specified complete half-year, service definition, rider exclusions, and source vintage. Do not substitute a full-year average or a removal notice. Treasury data remain the dated, preserved FRED snapshot; no case-level benchmark joins were performed in M5. Sample ordering, OWN/PEER precedence, and per-code stance handling will be settled before the steps that use them, without waiting for human approval.
