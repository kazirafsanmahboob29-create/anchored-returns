# Reproducing the project

The site can be used without installing the research software. Reproduction requires the preserved inputs, the Python environment and Node.js for browser and Worker tests. R is optional. No API key is required for the public market feeds.

## Research environment

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -e '.[test]'
./research national
./research check
./research overview
./research analyze
```

The `research` launcher uses an activated Python environment, a project `.venv`, or the original project environment. `requirements-lock.txt` records the original environment; `pyproject.toml` declares the smaller runtime dependency set.

Original PDFs are kept outside Git. The prepared project folder includes preserved originals for local use, and the separate source archive retains those files for transfer. Restore that archive at the repository root before a full evidence check. `scripts/fetch_sources.py` can alternatively retrieve documents from their recorded source URLs, accepting a file only when its SHA-256 matches the preserved record. If an endpoint now returns a different file, the check fails rather than silently replacing the historical source.

```sh
python scripts/fetch_sources.py --check
python scripts/fetch_sources.py --download
```

The original coding template and codebook are retained as methodological inputs. Personal project summaries and correspondence drafts are not needed to run the tools.

## Checks

```sh
python -m pytest -q
node --test tests/workspace/*.test.mjs tests/national/*.test.mjs
```

The browser calculations have separate tests for precision, missing values, joint services, proceeding weights and imported selections. Research tests validate the evidence trail and cross-software exports. Synthetic values used by tests are confined to test fixtures and are not empirical observations.

## Hosted web service

In the prepared repository:

```sh
cd web
node scripts/build.mjs
node --test tests/*.test.mjs
node scripts/validate-release.mjs
node scripts/preview.mjs
```

The preview prints its local URL. `web/research-release` is a portable export of the checked research state. The original working folders can recreate that export with `python -m scripts.build_hosted_release ../anchored-returns-site/research-release`.

R figures use base graphics. Native Stata code and Unicode DTA exports are included; native Stata execution has not been verified. The evidence manifest records which programs actually ran. Reproduction never creates independent human coding ratings.

The national-study download is self-contained for its own calculations. It includes the preserved EEI workbook, Treasury input files, Python modules and native statistical scripts. It does not require the New England original-order PDFs. See [national_study.md](national_study.md) for the exact exclusions, comparison windows and grouping rules.
