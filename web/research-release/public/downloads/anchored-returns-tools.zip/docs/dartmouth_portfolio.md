# Dartmouth portfolio integration

Target: https://journeys.dartmouth.edu/kazirafsanmahboob29/

The portfolio runs WordPress with the Libre theme. On October 26, 2026, its administration page redirected to Dartmouth institutional sign-in. Publishing through that account requires an authenticated session. No account credentials are stored in this project.

## Prepared page

`portfolio/dartmouth-page.html` contains a WordPress-compatible project-page fragment. `portfolio/figures/` contains the two verified R figures for the WordPress media library. `portfolio/index.html` is a standalone preview of the same case study. The page gives the research question, quantitative findings, checks and links to the working model tool. It does not include a fabricated GitHub URL. Add the repository link after the prepared repository has actually been uploaded.

## Hosting boundary

Journeys hosts the portfolio article and its images. The analysis tool is a separate JavaScript application with a hosted Worker for outbound data retrieval and R2 for complete source snapshots. A WordPress page is not a Python, R or Worker execution environment. Link to the application rather than assuming that a custom HTML block can run its server routes. Dartmouth also documents custom application hosting at host.dartmouth.edu: https://kb.thayer.dartmouth.edu/article/281-website . That is a different service from Journeys and would require its own deployment access.

The existing research Site is account-restricted unless its audience is explicitly changed. A portfolio link alone does not give visitors access. Public portfolio publication therefore requires both an authenticated Journeys session and a deliberate audience decision for the external tool. Do not paste an authentication bypass token into WordPress, source code, links or embeds.

## Repository

The prepared repository separates research modules, economic inputs, results and hosted application source. Its CI checks calculations without requiring the original-order PDF archive. Four selected economic histories and their attribution records are included; exploratory Moody’s downloads are excluded. Original PDFs remain in a separate source archive. The existing instruction is to prepare the repository for manual upload, rather than create or push a GitHub repository through this session.
