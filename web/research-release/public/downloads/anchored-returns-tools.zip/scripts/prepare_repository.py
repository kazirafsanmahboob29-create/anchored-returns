"""Prepare a portable source repository and a separate original-source archive."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(root,destination,web_root):
    root,destination,web_root=map(lambda p:Path(p).resolve(),(root,destination,web_root))
    if destination.exists():raise ValueError('Use a new destination; existing repository exports are preserved')
    destination.mkdir(parents=True)
    def copy(path,relative=None):
        target=destination/(relative or path.relative_to(root));target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    factor_dir='data/external/factor_research_2026-10-26/'
    factor_records=json.loads((root/factor_dir/'publication_allowlist.json').read_text())
    factor_allowed={r['path'] for r in factor_records['allowed_data_files']}|set(factor_records['allowed_documentation_files'])
    for directory in ('src','tests','scripts','analysis','presentation','data'):
        for path in sorted((root/directory).rglob('*')):
            if not path.is_file() or any(p in ('__pycache__','.cache') for p in path.parts):continue
            if directory=='data' and path.relative_to(root/'data').parts[0] in ('drafts','coding','number_candidates'):continue
            if directory=='data' and any(p.startswith(('source_search_','acquisition_')) for p in path.relative_to(root).parts):continue
            if directory=='data' and path.suffix not in ('.json','.csv','.xml','.xlsx','.txt','.html'):continue
            if str(path.relative_to(root)).startswith(factor_dir) and str(path.relative_to(root)) not in factor_allowed:continue
            if directory in ('src','tests','scripts') and path.suffix not in ('.py','.mjs','.json'):continue
            copy(path)
    docs=['ARCHITECTURE.md','DATA_DICTIONARY.md','DATA_RIGHTS.md','REPRODUCIBILITY.md','cohort_protocol_v0.1.4.md','cohort_protocol_v0.1.5.md','empirical_protocol_v0.1.3.md','eei_benchmarks.md','benchmark_reconstruction.md','research_brief.md','reliability_workflow.md','USAGE.md','data_sources.md','portfolio_case_study.md','national_study.md','regional_expansion.md','factor_analysis_plan_v0.1.0.md','factor_study.md','factor_source_review_2026-10-26.md','dartmouth_portfolio.md']
    for name in docs:copy(root/'docs'/name)
    for name in ('README.md','CITATION.cff','pyproject.toml','requirements-lock.txt','research','Makefile','pytest.ini'):copy(root/name)
    for name in ('Anchored_Returns_Codebook_v0.1.2.docx','Anchored_Returns_Pilot_Coding_Sheet_v0.1.2.xlsx'):copy(root/'project_docs'/name)
    for path in (root/'codebook').glob('*'):
        if path.is_file():copy(path)
    pointer=json.loads((root/'reports/analysis/latest.json').read_text());release=Path(pointer['manifest_path']).parent
    copy(root/'reports/analysis/latest.json');copy(root/'reports/presentation_build.json')
    for path in (root/release).rglob('*'):
        if path.is_file():copy(path)
    for path in (root/'reports/national-study').glob('*'):
        if path.is_file():copy(path)
    for path in (root/'reports/factor-study').glob('*'):
        if path.is_file():copy(path)
    for path in (root/'portfolio').rglob('*'):
        if path.is_file():copy(path)
    copy(root/'reports/independent_coding_kit_2026-10-03.zip')
    copy(root/'reports/sample_and_benchmarks_2026-10-04.md')
    for path in web_root.rglob('*'):
        if not path.is_file() or any(p in ('.git','dist','.runtime','node_modules') for p in path.relative_to(web_root).parts):continue
        if path.name=='.DS_Store':continue
        copy(path,Path('web')/path.relative_to(web_root))
    required={}
    rra=json.loads((root/'data/external/rra_historical_benchmarks.json').read_text())
    catalogs=[json.loads((root/'data/research/source_catalog.json').read_text())['sources'],rra['sources'],rra['unresolved_sources'],json.loads((root/'data/external/rra_context_sources.json').read_text())['sources']]
    for catalog in catalogs:
        for record in catalog:
            path=record['pdf_path'];expected=record['pdf_sha256']
            if digest(root/path)!=expected:raise ValueError('Source changed: '+path)
            required[path]=dict(path=path,sha256=expected,url=record['source_url'])
    for folder in ('reports/pdf_qa','reports/cohort_qa_2026-10-06','reports/cohort_qa_2026-10-21'):
        for path in (root/folder).rglob('*.png'):
            if path.name.startswith('sheet-'):continue
            relative=str(path.relative_to(root));required[relative]=dict(path=relative,sha256=digest(path),url=None)
    for relative in sorted(required):copy(root/relative)
    # The three context PDFs are methodological inputs, not all search files.
    for r in json.loads((root/'data/research/assistant_verified_case_facts.json').read_text())['facts']:
        for name in ('text_path',):
            if name in r and (root/r[name]).is_file():copy(root/r[name])
    manifest=dict(version='0.2.0',files=list(required.values()))
    (destination/'data/source_files.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (destination/'.gitignore').write_text('''.venv/\n.conda/\n.cache/\n__pycache__/\n.pytest_cache/\n*.py[cod]\n*.egg-info/\n.DS_Store\n.env\n.env.*\n!.env.example\nweb/dist/\nweb/.runtime/\ndata/**/*.pdf\nweb/research-release/public/**/*.pdf\nreports/pdf_qa/\nreports/cohort_qa_2026-10-06/\nreports/cohort_qa_2026-10-21/\n''')
    workflow=destination/'.github/workflows/checks.yml';workflow.parent.mkdir(parents=True)
    workflow.write_text('''name: Calculation and data checks\non: [push, pull_request]\npermissions:\n  contents: read\njobs:\n  checks:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-python@v5\n        with:\n          python-version: '3.11'\n      - uses: actions/setup-node@v4\n        with:\n          node-version: '22'\n      - run: python -m pip install -e '.[test]'\n      - run: python -m pytest tests/test_research_insights.py tests/test_research_sample.py tests/test_eei_benchmarks.py tests/test_national_study.py tests/test_factor_study.py -q\n      - run: node --test tests/workspace/*.test.mjs tests/national/*.test.mjs tests/factors/*.test.mjs\n      - run: node --test web/tests/market.test.mjs web/tests/factors.test.mjs\n''')
    (destination/'UPLOAD.md').write_text('''# Publishing the prepared repository\n\nThe folder is a complete local project. The Git index contains the source code, methods, validated records, public EEI workbook, figures and web modules. Original PDFs and source-review renderings are kept outside Git and are preserved in the separate source archive. No credentials or local environment folders are included.\n\nCreate an empty repository named `anchored-returns` on GitHub. From this folder, connect its exact URL and push:\n\n```sh\ngit remote add origin https://github.com/OWNER/anchored-returns.git\ngit push -u origin main\n```\n\nReplace OWNER with the GitHub account that owns the repository. Start with a private repository if the evidence archive is still being reviewed for distribution. The separate `anchored-returns-github.zip` contains only tracked upload files; the source archive is not needed for browsing the compiled dashboard or running the calculation checks.\n\nFor full evidence validation after cloning, restore the source archive:\n\n```sh\npython scripts/fetch_sources.py --archive /path/to/anchored-returns-sources.zip\n./research check\n```\n\nThe analysis source code and cohort are versioned independently of the hosted Site deployment. The existing Site is already deployed separately.\n''')
    subprocess.run(['git','init','-b','main',str(destination)],check=True,capture_output=True)
    subprocess.run(['git','-C',str(destination),'add','.'],check=True,capture_output=True)
    subprocess.run(['git','-C',str(destination),'-c','user.name=Kazi Rafsan Mahboob',
                    '-c','user.email=339712015+kazirafsanmahboob29-create@users.noreply.github.com',
                    'commit','-m','Publish research cohort, validated data and analysis workspace'],check=True,capture_output=True)
    files=subprocess.check_output(['git','-C',str(destination),'ls-files','-z']).split(b'\0')
    source_archive=destination.parent/'anchored-returns-sources.zip'
    with ZipFile(source_archive,'w',ZIP_DEFLATED) as archive:
        for relative in sorted(required):archive.write(destination/relative,relative)
        archive.writestr('SOURCE_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    upload_archive=destination.parent/'anchored-returns-github.zip'
    with ZipFile(upload_archive,'w',ZIP_DEFLATED) as archive:
        for raw in files:
            if raw:
                relative=raw.decode();archive.write(destination/relative,'anchored-returns/'+relative)
    return dict(repository=str(destination),tracked_files=sum(bool(f) for f in files),source_files=len(required),upload_zip=str(upload_archive),source_archive=str(source_archive))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('destination',type=Path);parser.add_argument('--web',type=Path,required=True);args=parser.parse_args()
    print(json.dumps(prepare(Path(__file__).resolve().parents[1],args.destination,args.web),indent=2))
