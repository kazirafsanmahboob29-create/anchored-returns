# Research release 0.1.4

Kazi Rafsan Mahboob | October 20, 2026

The fixed cohort contains 23 original written decisions: all 22 eligible records in the screened library and one supplemental Rhode Island settlement. The original 15-order quota proposal remains archived. The expanded cohort is bounded by the verified public-document library and does not establish a complete six-state census.

Eleven additional awards bring the entered numeric evidence to 66 facts across 20 decisions. Three cohort records have no entered award: two formula-setting decisions and one Vermont record requiring further numeric entry. Complete first-pass passage coding remains limited to three orders and 67 recorded units. Independent human coding agreement remains unmeasured.

The strict RRA series contains ten values for five half-years. It supplies all-service matches for 13 of the 23 cohort orders, or 14 of 25 service rows. Missing periods remain visible. These counts include formula-setting orders and do not represent the number of usable award comparisons.

The separate public EEI workbook adds 2,589 electric observations and 15 reconstructed base-rate half-years. Thirty-one quarterly counts and means reconcile with the workbook's controls. The reconstructed means are retrospective and do not establish the evidence available at an earlier written decision date. The dataset contains no gas series and no complete 2026 half-year. Both EEI finance-page routes were checked on October 20; the latest linked Rate Review workbook was 2025 Q3.

The analysis workspace supports record selection, state/service/date filters, order or proceeding weighting, separate national series, browser-local saved selections, share links, CSV exports and JSON analysis reports. Imported selections must match the current cohort fingerprint. The interface recalculates all summaries from its source records.

The original coding ledger, blinded rating packet and v0.1.3 protocol retain their original fingerprints. The v0.1.4 amendment changes cohort membership; it does not certify completion of data entry, coding or independent reliability.
