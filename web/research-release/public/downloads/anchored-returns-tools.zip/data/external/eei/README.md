# EEI historical electric benchmarks

This collection reconstructs a separate national electric comparison series from
the public [EEI Finance and Accounting resource library](https://www.eei.org/issues-and-policy/finance-and-tax).
The source is the **2025 Q3 Rate Review** workbook, retrieved October 20, 2026.
Its reporting date is September 30, 2025. The publication date has not been verified.

The workbook contains 2,589 observations in `All Rate Cases 2025Q3`, including
2,535 completed observations and 54 pending observations. The original sheet is
hidden in the publicly distributed workbook. No credentials or access restriction
were required to retrieve it. Three completed observations have authorization
dates after its stated reporting date. These are flagged in the reconstruction
report and do not enter any reported complete half-year.

## Files

| File | Contents |
| --- | --- |
| `eei_rate_review_2025_q3.xlsx` | Original source bytes |
| `source.json` | URL, source vintage, retrieval date and SHA-256 |
| `electric_observations.csv` | Every original observation, with sheet and row references |
| `half_year_benchmarks.csv` | Complete half-year means, denominators and row references |
| `reconstruction.json` | Benchmark records and 31 quarterly reconciliation checks |

## Calculation

The comparison series uses completed electric observations classified as
`Distribution` or `Vertically Integrated`. It excludes `Limited-Issue Rider` and
`Transmission` observations. The workbook's status `Settled` means that a case has
a completed authorization entry. It is not a classification of negotiated versus
litigated outcomes.

Each observation with a reported positive ROE receives equal weight. Missing ROEs
remain missing and do not enter the denominator. The mean equals the sum of the
individual ROE percentages divided by the number of observed ROEs. Two-decimal
display values use decimal rounding with ties rounded upward. Exact sums, counts
and unrounded means are retained. Two-decimal source ROEs are normalized only to
remove Excel serialization differences smaller than 0.0000000001 percentage points.

The reconstruction also retains an all-case series for sensitivity comparisons.
The source's quarterly counts and averages are reproduced for all 31 quarters from
2018 Q1 through 2025 Q3. These checks use the workbook's separate `Summary` sheet.

| Period | Base-rate decisions with ROE | Sum of ROE percentages | Mean ROE |
| --- | ---: | ---: | ---: |
| 2018 H2 | 19 | 181.35 | 9.54% |
| 2023 H1 | 12 | 115.70 | 9.64% |
| 2023 H2 | 36 | 347.88 | 9.66% |
| 2024 H2 | 27 | 265.32 | 9.83% |
| 2025 H1 | 18 | 174.23 | 9.68% |

## Interpretation

These are retrospective EEI workbook reconstructions. They remain separate from
the historical RRA original-report series. The current workbook may incorporate
revisions and does not establish which observations were available on an earlier
commission decision date. It contains electric observations only. It provides no
gas comparison and no complete 2026 half-year.

The 2023 annual source table has 91 completed observations and 63 reported ROEs.
Their case-weighted mean rounds to 9.60%, or 9.66% for the 48 base-rate observations
with ROEs. The corresponding 2024 figures are 78 completed observations, 55 reported
ROEs, a 9.74% all-case mean and a 9.78% mean for 41 base-rate observations with ROEs.
These totals agree with the respective original RRA annual-report control values.
Agreement of these aggregates does not prove identical historical coverage for
every observation.

EEI's annual Financial Review headlines report 9.58% for 2023 and 9.73% for 2024.
The unweighted average of each year's four quarterly workbook means rounds to those
figures. This is an arithmetic reconciliation, not a confirmed statement of EEI's
annual headline calculation. Its annual chart footnote describes returns as
equal-weighted without specifying the aggregation used for the annual headline.
The half-year series here always weights individual observations equally.

## Reproduction

```python
from src.eei_benchmarks import eei_report

report = eei_report(".")
assert all(check["status"] == "passed" for check in report["controls"])
```

The parser uses Python's standard library, checks the original file fingerprint,
reads cached source values and never executes formulas or macros. Each benchmark
includes the original worksheet row numbers that enter its calculation. An optional
candidate list produces same-service, previous-half-year joins with explicit
retrospective status.

Original publication rights remain with EEI and the underlying data owners. This
collection does not assert a new license over their workbook.
